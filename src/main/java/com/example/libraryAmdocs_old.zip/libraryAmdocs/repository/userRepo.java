package com.example.libraryAmdocs.repository;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.libraryAmdocs.model.Books;
import com.example.libraryAmdocs.model.Users;



@Repository
public class userRepo {
	
	@Autowired
	Users userJson;
		

	/* Retrieve Users list from USERS table */
	public List<Users> userFetch() throws IOException {
			 	List<Users> excelJsonModelArray = new ArrayList<Users>();
			 	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			 	String UserListQuery = "SELECT * FROM USERS";
			 	  System.out.println(UserListQuery);
			 	 try (Connection conn = this.connect();
			 		    PreparedStatement pstmt = conn.prepareStatement(UserListQuery)) {

			 		    System.out.println(pstmt);
			 		   
			 		    ResultSet rs = pstmt.executeQuery();
			 		    while(rs.next()) {
			 		    System.out.println("User id = " + rs.getString("user_id"));
			 		    System.out.println("User name = " + rs.getString("user_name"));
			 		    Users userResult = new Users();
			 		    try {
			 		      Date today = df.parse(rs.getString("activation_date"));
			 		      System.out.println("Activation-Date = " + df.format(today));
			 		      userResult.setActivationDate(df.format(today));
			 		      			 		      
			 		    } catch (ParseException e) {
			 		     e.printStackTrace();
			 		    }
			 		    	 		    
			 		   userResult.setAccountName(rs.getString("account"));
			 		   userResult.setAdminFlag(rs.getString("admin").charAt(0));
			 		   userResult.setEmailID(rs.getString("email"));
			 		   userResult.setPhoneNumber(rs.getInt("mobile"));
			 		   
			 		  try {
			 		      Date today = df.parse(rs.getString("expiration_date"));
			 		      System.out.println("Expiration-Date = " + df.format(today));
			 		      
			 		      userResult.setExpirationDate(df.format(today));		 		      
			 		    } catch (ParseException e) {
			 		     e.printStackTrace();
			 		    }
			 		    excelJsonModelArray.add(userResult);
			 		  		   
			 		    }
			 		  
			 		   System.out.println("New user was Added. exiting function");
			 		   conn.close();
			 		  } catch (SQLException e) {
			 		   System.out.println(e.getMessage());
			 		   
			 		  }
			 	 
			 	 return excelJsonModelArray; 
 
  }
}
