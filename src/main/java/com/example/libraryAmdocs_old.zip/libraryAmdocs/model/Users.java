package com.example.libraryAmdocs.model;

import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class Users {
	
	int userID;
    String userName;
    String accountName;
    int phoneNumber;
    String emailID;
    char adminFlag;
    String activationDate;
    String expirationDate;

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public char getAdminFlag() {
		return adminFlag;
	}

	public void setAdminFlag(char adminFlag) {
		this.adminFlag = adminFlag;
	}

	public String getActivationDate() {
		return activationDate;
	}

	public void setActivationDate(String string) {
		this.activationDate = string;
	}

	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	public Users() {
		// TODO Auto-generated constructor stub
	}

}
