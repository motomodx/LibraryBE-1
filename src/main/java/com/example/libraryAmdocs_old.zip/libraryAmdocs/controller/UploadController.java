package com.example.libraryAmdocs.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.libraryAmdocs.model.*;
import com.example.libraryAmdocs.service.UploadService;

@RestController
public class UploadController {

	@Autowired
	UploadService uploadService;
	
	//@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addBook")
	//public void updateExcel(@RequestBody BookTabStruct obj ) throws IOException 
	public void addBook(@RequestBody Books obj ) throws IOException
	{
		System.out.println("inside addBook Interface");
		uploadService.addBookService(obj);
	}

	//@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/readBook")
	public List<Books> readBooksList() throws Exception
	{
		System.out.println("inside readBooksList Interface");
		return uploadService.readBooksData();
	}
	/*
	@RequestMapping("/readExcel/{id}")
	public BookTabStruct getBook(@PathVariable int id) {
		return uploadService.getBook(id);
	}*/
}
