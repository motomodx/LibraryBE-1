package com.example.libraryAmdocs.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.libraryAmdocs.service.RequestService ;

@RestController
public class RequestController {
	
	RequestService requestServiceRec ;

}
